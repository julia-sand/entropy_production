
------

Entropy Production
------

I forked this repository to try to solve an optimal transport assignment. 

main = contains the variable definitions and time mesh. outputs all the main parameters of each run.

optentropy = computes the overdamped cell problem from the solution of a optimal transport problem. 

distributionanddrift = computes the corrections to the drift and distributions for the underdamped

